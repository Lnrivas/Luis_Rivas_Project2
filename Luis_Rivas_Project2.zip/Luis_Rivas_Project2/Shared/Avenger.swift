//
//  Avenger.swift
//  Luis_Rivas_Project2
//
//  Created by Luis Rivas on 4/5/22.
//

import Foundation
import SwiftUI
struct Avenger : Codable, Identifiable {
    var id: String
    var name: String
    var description: String
}
