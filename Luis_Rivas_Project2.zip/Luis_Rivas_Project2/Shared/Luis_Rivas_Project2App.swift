//
//  Luis_Rivas_Project2App.swift
//  Shared
//
//  Created by Luis Rivas on 3/27/22.
//

import SwiftUI

@main
struct Luis_Rivas_Project2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
